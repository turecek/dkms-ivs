var searchData=
[
  ['calc',['Calc',['../namespace_calc.html',1,'']]],
  ['properties',['Properties',['../namespace_calc_1_1_properties.html',1,'Calc']]]
];
