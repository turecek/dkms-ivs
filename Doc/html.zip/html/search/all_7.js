var searchData=
[
  ['lastoperation',['LastOperation',['../group__gui_fc.html#ga8015560ed8bbeb4c310f9449dde66848',1,'Calc::CalcForm']]]
];
