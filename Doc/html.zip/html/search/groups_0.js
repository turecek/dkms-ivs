var searchData=
[
  ['complicated_20math_20operations',['Complicated Math Operations',['../group__comp_op.html',1,'']]]
];
