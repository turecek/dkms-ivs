var indexSectionsWithContent =
{
  0: "bcdefgilmprs",
  1: "cm",
  2: "cm",
  3: "cm",
  4: "bcdflmp",
  5: "cegmrs",
  6: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Vše",
  1: "Třídy",
  2: "Prostory jmen",
  3: "Soubory",
  4: "Funkce",
  5: "Skupiny",
  6: "Stránky"
};

